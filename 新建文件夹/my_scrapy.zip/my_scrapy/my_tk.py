import tkinter
from tkinter import *  # 导入tkinter库的所有模块
import tkinter.filedialog  # 导入tkinter的文件对话框模块
from op_scrapy import Op_scrapy  # 导入自定义的Op_scrapy类
import time, threading


# 定义一个名为My_tk的类
class My_tk():
    def __init__(self, tk):
        self.op_scrapy = Op_scrapy()  # 创建一个Op_scrapy对象，用于执行爬虫操作
        # 界面基本设置
        self.root = tk
        self.root.title("073的scrapy爬虫")
        self.root.geometry("300x300")
        # 创建初始爬虫功能选择按钮
        self.choice_frame = Frame(self.root)  # 创建一个Frame对象，用于存放按钮
        self.poetry_button = Button(self.choice_frame, text='爬取古诗', command=self.show_poetry)  # 创建爬取古诗按钮，并绑定点击事件
        self.choice_frame.pack()  # 在窗口中显示Frame对象
        self.poetry_button.pack(side=LEFT)  # 在Frame对象中显示按钮对象，靠左对齐
        self.start_button = Button(self.choice_frame, text='爬取简历', command=self.show_resume)
        self.start_button.pack(side=LEFT)
        self.douban_button = Button(self.choice_frame, text='爬取豆瓣', command=self.show_douban)
        self.douban_button.pack(side=LEFT)
        self.jd_button = Button(self.choice_frame, text='爬取京东', command=self.show_jd)
        self.jd_button.pack(side=LEFT)
        with open('jd_status.txt', 'w') as f:
            f.write('0')

    def show_poetry(self):
        # 隐藏[选择]界面，显示为爬取【获取古诗】界面
        # self.Tid = False
        self.choice_frame.pack_forget()  # 隐藏[选择]界面
        self.build_poetry_frame()  # 创建【获取古诗】界面

    def build_poetry_frame(self):
        self.poetry_frame = Frame(self.root, height=50, width=100)  # 创建一个Frame对象作为古诗界面的容器，设置高度为50，宽度为100
        self.poetry_frame.pack(anchor='center')  # 在窗口中显示该Frame对象，并居中对齐
        # 创建一个Button对象用于返回按钮，显示文本为"返回"，并绑定self.back方法作为点击事件处理函数
        go_back_button = Button(self.poetry_frame, text='返回', command=self.back)
        go_back_button.pack(anchor='w')  # 在poetry_frame容器中显示返回按钮，靠左对齐
        # 创建一个Button对象用于爬取古诗按钮，显示文本为"爬取古诗"，并绑定self.go_spider_poetry方法作为点击事件处理函数
        self.go_spider_button = Button(self.poetry_frame, text='爬取古诗', command=self.go_spider_poetry)
        self.go_spider_button.pack(anchor='center')  # 在poetry_frame容器中显示爬取古诗按钮，居中对齐
        self.spidering_info = Listbox(self.poetry_frame, width=30)  # 创建一个Listbox对象用于显示爬取信息，设置宽度为30
        self.spidering_info.pack(anchor='center')  # 在poetry_frame容器中显示爬取信息的Listbox，居中对齐

    def go_spider_poetry(self):
        self.spidering_info.insert('end', '开始爬虫')  # 在spidering_info Listbox的末尾插入字符串"开始爬虫"
        self.go_spider_button.config(state=tkinter.DISABLED)
        self.the_running_info = threading.Thread(target=self.show_running_info)
        self.the_running_info.start()
        op_result = self.op_scrapy.start('poetry')    # 调用op_scrapy对象的start方法开始执行名为'poetry'的爬虫操作，并将结果保存在op_result变量中
        if op_result == False:
            self.spidering_info.insert('end', '爬虫方案有误！！！')


    def show_resume(self):
        # 隐藏[选择]界面，显示为爬取【获取简历】界面
        # self.Tid = False
        self.choice_frame.pack_forget()  # 隐藏[选择]界面
        self.build_resume_frame()  # 创建【获取简历】界面

    # 创建爬取简历界面
    def build_resume_frame(self):
        self.resume_frame = Frame(self.root, height=50, width=100)
        self.resume_frame.pack(anchor='center')
        go_back_button = Button(self.resume_frame, text='返回', command=self.back)
        go_back_button.pack(anchor='w')
        self.go_spider_button = Button(self.resume_frame, text='爬取简历', command=self.go_spider_resume)
        self.go_spider_button.pack(anchor='center')
        self.spidering_info = Listbox(self.resume_frame, width=30)
        self.spidering_info.pack(anchor='center')

    def go_spider_resume(self):
        self.spidering_info.insert('end', '开始爬虫')
        self.go_spider_button.config(state=tkinter.DISABLED)
        self.the_running_info = threading.Thread(target=self.show_running_info)
        self.the_running_info.start()
        op_result = self.op_scrapy.start('resume')
        if op_result == False:
            self.spidering_info.insert('end', '爬虫方案有误！！！')


    def show_douban(self):
        # 隐藏[选择]界面，显示为【获取豆瓣】界面
        # self.Tid = False
        self.choice_frame.pack_forget()  # 隐藏[选择]界面
        self.build_douban_frame()  # 创建【豆瓣top】界面

    def build_douban_frame(self):
        # 豆瓣界面
        self.douban_frame = Frame(self.root, height=50, width=100)
        self.douban_frame.pack(anchor='center')
        go_back_button = Button(self.douban_frame, text='返回', command=self.back)
        go_back_button.pack(anchor='w')
        self.go_spider_button = Button(self.douban_frame, text='豆瓣读书Top',
                                       command=self.go_spider_douban)
        self.go_spider_button.pack(anchor='center')
        self.spidering_info = Listbox(self.douban_frame, width=30)
        self.spidering_info.pack(anchor='center')

    def go_spider_douban(self):
        self.spidering_info.insert('end', '开始爬虫')
        self.go_spider_button.config(state=tkinter.DISABLED)
        self.the_running_info = threading.Thread(target=self.show_running_info)
        self.the_running_info.start()
        op_result = self.op_scrapy.start('douban')
        if op_result == False:
            self.spidering_info.insert('end', '爬虫方案有误！！！')


    def show_jd(self):
        # 隐藏[选择]界面，显示为【获取京东】界面
        # self.Tid = False
        self.choice_frame.pack_forget()  # 隐藏[选择]界面
        self.build_jd_frame()  # 创建【爬取京东】界面

    def build_jd_frame(self):
        # 京东界面
        self.jd_frame = Frame(self.root, height=50, width=100)
        self.jd_frame.pack(anchor='center')
        go_back_button = Button(self.jd_frame, text='返回', command=self.back)
        go_back_button.pack(anchor='w')
        self.go_spider_button = Button(self.jd_frame, text='京东商品数据', command=self.go_spider_jd)
        self.go_spider_button.pack(anchor='center')
        self.spidering_info = Listbox(self.jd_frame, width=30)
        self.spidering_info.pack(anchor='center')

    def go_spider_jd(self):
        self.spidering_info.insert('end', '开始爬虫')
        self.go_spider_button.config(state=tkinter.DISABLED)
        self.the_running_info = threading.Thread(target=self.show_running_info)
        self.the_running_info.start()
        op_result = self.op_scrapy.start('jd')
        self.go_jd_login.config(state=tkinter.NORMAL)
        if op_result == False:
            self.spidering_info.insert('end', '爬虫方案有误！！！')


    def show_running_info(self):
        running = True
        time1 = int(time.time())
        self.spidering_info.insert('end', '爬虫线程启动')
        self.spidering_info.insert('end', '爬虫线程运行中......')
        while running:
            now_time = int(time.time() - time1)
            if now_time % 2 == 0:
                running = self.op_scrapy.check_scrapying()
        self.spidering_info.insert('end', '爬虫线程关闭')


    # 旧用法
    # def show_running_info(self):
    #     running = True  # 初始化变量running为Ture，表示正在运行
    #     time1 = int(time.time())  # 获取当前时间，用于计算运行时间
    #     self.spidering_info.insert('end', '爬虫中... ...')  # 在指定位置插入爬虫运行信息
    #     while running:
    #         now_time = int(time.time() - time1)  # 计算当前经过的时间
    #         if now_time % 2 == 0:  # 判断当前时间是否为偶数
    #             running = self.op_scrapy.check_scrapying()  # 调用op_scrapy对象的check_scrapying()方法，检查是否在进行爬取任务
    #     self.spidering_info.insert('end', '爬取数据完毕')  # 插入爬取数据完毕的信息


    def back(self):
        # 返回上一级选择界面，把诗句/简历界面的信息，控件全部删除(ps:不然再进入时会有痕迹)
        if 'poetry_frame' in dir(self):
            self.poetry_frame.destroy()  # 删除古诗界面(控件)
            delattr(self, 'poetry_frame')  # 彻底删除属性
        elif 'resume_frame' in dir(self):
            self.resume_frame.destroy()
            delattr(self, 'resume_frame')
        elif 'douban_frame' in dir(self):
            self.douban_frame.destroy()  # 删除豆瓣界面(控件)
            delattr(self, 'douban_frame')
        elif 'jd_frame' in dir(self):
            self.jd_frame.destroy()  # 删除京东界面(控件)
            delattr(self, 'jd_frame')
        self.choice_frame.pack()  # 显示最初始的选择界面
        print(self.op_scrapy.spider_pid)
        self.op_scrapy.stop_scrapy()  # 结束exe程序
