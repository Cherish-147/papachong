import time, psutil, subprocess, multiprocessing  # 导入所需的库和模块
from scrapy.crawler import CrawlerProcess  # 导入Scrapy相关库
from scrapy.utils.project import get_project_settings  # 导入Scrapy项目设置相关库
from my_scrapy.spiders.poetry import poetrySpider  # 导入自定义的爬虫模块
from my_scrapy.spiders.resume import resumeSpider
from my_scrapy.spiders.douban import DoubanSpider
from my_scrapy.spiders.jd import JdSpider


# 定义一个名为Op_scrapy的类
class Op_scrapy():
    def __init__(self):
        self.spider_pid = 123456  # 初始化变量spider_pid为123456

    # 定义名为start的方法，用于启动爬虫
    def start(self, spider_name):
        if spider_name == 'poetry':
            spider = poetrySpider
        elif spider_name == 'resume':  # 如果传入的爬虫名为resume
            spider = resumeSpider  # 则spider赋值为resumeSpider类
        elif spider_name == 'douban':
            spider = DoubanSpider
        elif spider_name == 'jd':
            spider = JdSpider
        else:
            return
        # 创建一个多进程，目标为start_crawl函数，传入参数spider
        self.the_scrapy = multiprocessing.Process(target=start_crawl, args=(spider,))
        self.the_scrapy.start()  # 启动多进程
        self.spider_pid = self.the_scrapy.pid  # 将多进程的pid赋值给spider_pid


    # ===============如果scrapy还在运行，那么杀死进程===============
    def stop_scrapy(self):  # 定义名为stop_scrapy的方法，用于停止爬虫
        # 根据pid判断，如果scrapy还在运行，那么结束进程，
        # 同时设定爬取详情窗口的is_scrapying为False终止tree里的循环‘’‘
        if self.spider_pid in psutil.pids():  # main.py的继承类定义了该id，运行爬虫时设定
            print('scrapy还在运行！')
            time.sleep(1)
            subprocess.Popen("taskkill /pid %s /f" % self.spider_pid, shell=True)   # 终止该进程
    # ===============如果scrapy还在运行，那么杀死进程===============

    # 定义名为check_scrapying的方法，用于检查爬虫是否在运行中
    def check_scrapying(self):
        if self.spider_pid in psutil.pids():   # 如果spider_pid在当前活动进程id列表中
            return True  # 返回True表示爬虫在运行中
        else:
            return False  # 返回False表示爬虫不在运行


# 定义名为start_crawl的函数，用于启动爬虫过程
def start_crawl(spider):
    process = CrawlerProcess(get_project_settings())  # 创建CrawlerProcess对象，使用Scrapy项目设置
    process.crawl(spider)  # 启动指定的爬虫
    process.start()  # 开始爬取过程
