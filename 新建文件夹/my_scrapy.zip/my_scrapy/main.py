from tkinter import *  # 导入tkinter库的所有模块
from my_tk import My_tk  # 导入自定义的My_tk类


# 定义一个名为MyScrapyWindow的类，继承自My_tk类
class MyScrapyWindow(My_tk):
    def __init__(self, tk):
        super().__init__(tk)  # 调用父类的构造函数进行初始化


# 定义一个名为begin的函数
def begin():
    root = Tk()  # 创建一个Tk窗口对象
    MyScrapyWindow(root)  # 创建一个MyScrapyWindow对象，传入Tk窗口对象作为参数
    root.mainloop()  # 进入Tk事件循环，处理窗口事件


if __name__ == '__main__':  # 判断当前脚本是否为主程序入口
    begin()  # 调用begin函数，启动程序

