# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql
import pandas as pd
# useful for handling different item types with a single interface
from itemadapter import ItemAdapter


# 定义了一个名为MyScrapyPipeline的类，它包含一个process_item方法。
# 该方法接收两个参数：item表示爬虫提取到的Item对象，spider表示当前爬虫的实例。
class MyScrapyPipeline:
    def __init__(self):
        self.count = 0
        self.df = pd.DataFrame(columns=['index', 'title', 'publish',
                                        'score', 'selogen', 'source', 'type'])
        self.conn = pymysql.Connect(
            host='localhost',
            port=3306,
            user='root',
            password='1234',
            database='scrapy_test',
            cursorclass=pymysql.cursors.DictCursor
        )
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        # 针对不同的爬虫进行不同的保存处理，对应spiders/poetry.py中的name
        # 根据spider.name的值来判断当前爬虫的类型，
        # 如果爬虫名为poetry_spider，则将item['poetrys']写入名为poetrys.txt的文件中
        if spider.name == 'poetry_spider':
            with open('poetrys.text', 'w', encoding='utf-8') as f:
                f.write(item['poetrys'])
        elif spider.name == 'resume_spider':
            with open('resumes.text', 'w', encoding='utf-8') as f:
                f.write(item['resumes'])
        elif spider.name == 'douban_spider':
            df_cell = pd.DataFrame({
                'index': [self.count],
                'title': [item.get('title','')],
                'publish': [item.get('publish','')],
                'score': [item.get('score','')],
                'selogen': [item.get('selogen','')],
                'source': ['豆瓣读书'],
                'type': ['Top250'],
            })
            self.count += 1
            self.df = pd.concat([self.df,df_cell], ignore_index=True)
            sql = """insert into douban_top (title,publish,score,selogen,source,type)values (%s,%s,%s,%s,%s,%s)"""
            self.cursor.execute(sql, (
                item.get('title', ''),
                item.get('publish', ''),
                item.get('score', ''),
                item.get('selogen', ''),
                '豆瓣读书',
                'Top250'
            ))
            self.conn.commit()
        elif spider.name == 'jd_spider':
            sql = """insert into jd_goods (name,price,commit_num,key_word,sales)values (%s,%s,%s,%s,%s)"""
            self.cursor.execute(sql, (
                item.get('name', ''),
                item.get('price', ''),
                item.get('commit_num', ''),
                item.get('key_word', ''),
                item.get('sales', '')
            ))
            self.conn.commit()
        return item

    def close_spider(self,spider):
        if spider.name == 'douban_spider':
            self.df.to_excel('douban.xlsx', index=False)
            self.cursor.close()
            self.conn.close()
