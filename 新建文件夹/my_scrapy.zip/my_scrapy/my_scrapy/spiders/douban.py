import bs4
import scrapy
from ..items import DoubanItem


class DoubanSpider(scrapy.Spider):
    name = "douban_spider"
    allowed_domains = ['book.douban.com']
    # 第一贝
    # https://book.douban.com/top250?start=日
    # 第二页
    # https://book.douban.con/top250?start=25
    #产第三页
    # https://book.douban.com/top250?start=50
    start_urls =[]
    for x in range(10):
        url = 'https://book.douban.com/top250?start=' + str(x * 25)
        start_urls.append(url)

    def parse(self, response):
        bs = bs4.BeautifulSoup(response.text, 'html.parser')
        datas = bs.find_all('tr', class_="item")
        for data in datas:
            item = DoubanItem()
            item['title'] = data.find_all('a')[1]['title']
            item['publish'] = data.find('p', class_='pl').text
            item['score'] = data.find('span', class_='rating_nums').text
            if data.find('span', class_='inq'):
                item['selogen'] = data.find('span', class_='inq').text
            else:
                item['selogen'] =""
            print(item['title']+':' + item['selogen'])
            yield item
