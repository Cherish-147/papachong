import scrapy  # 导入Scrapy库
from bs4 import BeautifulSoup  # 导入BeautifulSoup库
from ..items import PoetryItem  # 导入自定义的PoetryItem类


# 定义一个名为poetrySpider的爬虫类，继承自Scrapy的Spider类
class poetrySpider(scrapy.Spider):
    name = "poetry_spider"  # 设置爬虫名称
    start_urls = ['http://127.0.0.1:9000/poetry']  # 初始爬取的URL列表

    def parse(self, response):  # 定义解析方法，处理响应的HTML内容
        html = response.text  # 获取网页内容的文本形式
        soup = BeautifulSoup(html, 'html.parser')  # 使用BeautifulSoup解析HTML内容
        contents = soup.findAll(class_='view_text')  # 查找所有class为'view_text'的元素
        get_html_poetrys = ''  # 初始化一个变量来存储简历信息的HTML内容
        for value in contents:  # 遍历找到的所有简历元素
            get_html_poetrys += value.find('h2').text + "\n"
            get_html_poetrys += value.find('p').text + "\n"
        print(get_html_poetrys)  # 打印获取到的古诗
        item = PoetryItem()  # 创建一个PoetryItem对象
        item['poetrys'] = get_html_poetrys  # 将简历信息存储到PoetryItem对象中的'poetrys'字段
        yield item  # 使用yield语句将PoetryItem对象传递给引擎处理


